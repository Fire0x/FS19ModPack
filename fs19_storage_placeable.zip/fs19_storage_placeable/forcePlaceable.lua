-- forcePlaceable by Phoenix Modding. THX to estyx for Support on GDN! 

forcePlaceable = {}; 

function forcePlaceable:loadMap(name)
	PlacementScreenController.isPlacementValid = Utils.overwrittenFunction(PlacementScreenController.isPlacementValid, forcePlaceable.isPlacementValid);
end; 

function forcePlaceable:deleteMap()
end; 
function forcePlaceable:update(dt) 
end; 

function forcePlaceable:mouseEvent(posX, posY, isDown, isUp, button) 
end; 

function forcePlaceable:draw(forcePlaceable)
end;

function forcePlaceable:keyEvent(unicode, sym, modifier, isDown) 
end; 

function forcePlaceable:isPlacementValid(superFunc, ...)  
	return true;
end
addModEventListener(forcePlaceable);